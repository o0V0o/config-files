local dir_sep, path_templ_sep, templ_sub_point, win_exe_dir, luaopen_ignore = string.match ( package.config, '(.+)\n(.+)\n(.+)\n(.+)\n(.+)' )
